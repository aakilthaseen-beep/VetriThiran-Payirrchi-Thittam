import os
import tempfile
import unittest
from pathlib import Path

os.environ["GEMINI_API_KEY"] = ""

import backend.config as config
TEST_DB = Path(tempfile.gettempdir()) / "pocketsmart_test.db"
if TEST_DB.exists(): TEST_DB.unlink()
config.DATABASE_PATH = TEST_DB

from backend.app import app
from backend.database import init_db, get_db

class PocketSmartAPITest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()

    def setUp(self):
        self.client = app.test_client()
        with get_db() as db:
            db.execute("DELETE FROM transactions")
            db.execute("UPDATE settings SET value='0' WHERE key='monthly_budget'")

    def test_health(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["status"], "ok")

    def test_create_and_list_transaction(self):
        response = self.client.post("/api/transactions", json={
            "title":"Lunch","amount":120,"type":"expense","category":"Food"
        })
        self.assertEqual(response.status_code, 201)
        response = self.client.get("/api/transactions")
        self.assertEqual(len(response.json), 1)
        self.assertEqual(response.json[0]["title"], "Lunch")

    def test_summary_and_budget(self):
        self.client.put("/api/budget", json={"monthly_budget":10000})
        self.client.post("/api/transactions", json={
            "title":"Salary","amount":15000,"type":"income","category":"Other"
        })
        self.client.post("/api/transactions", json={
            "title":"Books","amount":2000,"type":"expense","category":"Education"
        })
        response = self.client.get("/api/summary")
        self.assertEqual(response.json["income"], 15000)
        self.assertEqual(response.json["expenses"], 2000)
        self.assertEqual(response.json["balance"], 13000)
        self.assertEqual(response.json["budget"], 10000)

    def test_invalid_transaction(self):
        response = self.client.post("/api/transactions", json={
            "title":"","amount":-10,"type":"expense"
        })
        self.assertEqual(response.status_code, 400)

    def test_delete_transaction(self):
        created = self.client.post("/api/transactions", json={
            "title":"Test","amount":10,"type":"expense","category":"Other"
        })
        transaction_id = created.json["id"]
        response = self.client.delete(f"/api/transactions/{transaction_id}")
        self.assertEqual(response.status_code, 200)
        response = self.client.get("/api/transactions")
        self.assertEqual(response.json, [])

if __name__ == "__main__":
    unittest.main()
