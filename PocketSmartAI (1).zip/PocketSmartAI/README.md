# PocketSmart AI — Your Smart Budget & Recommendation Assistant

Complete student-project implementation based on the uploaded project brief. The brief identifies the Generative AI with Google track and the PocketSmart AI project title, but does not contain implementation specifications.

## Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Python + Flask
- Database: SQLite
- AI: Google Gemini via the official `google-genai` SDK

## Features
- Income/expense tracking
- Monthly budget
- Summary dashboard
- Category spending
- Gemini budget insight
- Gemini recommendation assistant
- REST APIs
- Automated API tests
- Works for non-AI features even without a Gemini key

## Structure
```text
PocketSmartAI/
├── backend/
│   ├── __init__.py
│   ├── app.py
│   ├── config.py
│   ├── database.py
│   ├── gemini_service.py
│   └── schemas.py
├── data/
│   └── .gitkeep
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── style.css
├── tests/
│   └── test_api.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## VS Code setup

1. Install Python 3.11+.
2. Open this folder in VS Code.
3. Create a terminal.
4. Create and activate a virtual environment:

### Windows PowerShell
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### Windows CMD
```cmd
python -m venv .venv
.venv\Scripts\activate
```

5. Install packages:
```bash
pip install -r requirements.txt
```

6. Copy `.env.example` to `.env`.
7. Put your Gemini API key in `.env`:
```text
GEMINI_API_KEY=your_real_key
```
8. Run:
```bash
python -m backend.app
```
9. Open `http://127.0.0.1:5000`.

## Testing
Run:
```bash
python -m unittest discover -s tests -v
```

## API
- `GET /api/health`
- `GET /api/transactions`
- `POST /api/transactions`
- `DELETE /api/transactions/<id>`
- `GET /api/summary`
- `GET /api/budget`
- `PUT /api/budget`
- `POST /api/ai/insight`
- `POST /api/ai/recommend`

## Manual test
Set a budget, add income, add expenses in several categories, generate an AI insight, then test the recommendation assistant.

The recommendation feature does not claim live prices, availability, discounts, or merchant stock. For production use, add authentication, HTTPS, rate limiting, stronger validation, logging, and a production WSGI server.
