import json
from google import genai
from .config import GEMINI_API_KEY, GEMINI_MODEL

class GeminiService:
    def __init__(self):
        self.enabled = bool(GEMINI_API_KEY)
        self.client = genai.Client(api_key=GEMINI_API_KEY) if self.enabled else None

    def _generate(self, prompt: str) -> str:
        if not self.enabled:
            raise RuntimeError(
                "Gemini is not configured. Add GEMINI_API_KEY to the .env file."
            )
        response = self.client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()

    @staticmethod
    def _clean_json(text: str):
        text = text.strip()
        if text.startswith("```"):
            lines = text.splitlines()
            lines = [line for line in lines if not line.strip().startswith("```")]
            text = "\n".join(lines).strip()
        return json.loads(text)

    def budget_insight(self, summary: dict) -> dict:
        prompt = f"""
You are PocketSmart AI, a responsible personal budgeting assistant.

Analyze these user's budget numbers:
{json.dumps(summary, indent=2)}

Return ONLY valid JSON with this exact shape:
{{
  "headline": "short headline",
  "summary": "2-4 sentence practical summary",
  "actions": ["action 1", "action 2", "action 3"],
  "warning": "one short caution, or empty string"
}}

Rules:
- Do not invent transactions.
- Use only the supplied numbers.
- Avoid financial guarantees.
- Give practical budgeting guidance.
- Keep the language simple.
"""
        raw = self._generate(prompt)
        try:
            result = self._clean_json(raw)
            if not isinstance(result, dict):
                raise ValueError("Expected an object.")
            result.setdefault("headline", "Budget insight")
            result.setdefault("summary", "")
            result.setdefault("actions", [])
            result.setdefault("warning", "")
            return result
        except Exception:
            return {
                "headline": "Budget insight",
                "summary": raw,
                "actions": [],
                "warning": "AI returned an unstructured response.",
            }

    def recommendation(self, category: str, budget: float, preference: str, summary: dict) -> dict:
        prompt = f"""
You are PocketSmart AI, a recommendation assistant.

User request:
- Category: {category}
- Maximum budget: {budget}
- Preference: {preference}
- Current budget summary: {json.dumps(summary)}

Return ONLY valid JSON:
{{
  "recommendation": "one concise recommendation approach",
  "why": ["reason 1", "reason 2"],
  "shopping_checklist": ["check 1", "check 2", "check 3"],
  "note": "short limitation/caution"
}}

Rules:
- Do not claim live prices, availability, discounts, or specific merchant stock.
- Do not fabricate product specifications.
- Keep suggestions general unless the user supplied enough detail.
- Never encourage spending beyond the stated budget.
"""
        raw = self._generate(prompt)
        try:
            result = self._clean_json(raw)
            if not isinstance(result, dict):
                raise ValueError("Expected an object.")
            result.setdefault("recommendation", raw)
            result.setdefault("why", [])
            result.setdefault("shopping_checklist", [])
            result.setdefault("note", "")
            return result
        except Exception:
            return {
                "recommendation": raw,
                "why": [],
                "shopping_checklist": [],
                "note": "AI returned an unstructured response.",
            }

gemini_service = GeminiService()
