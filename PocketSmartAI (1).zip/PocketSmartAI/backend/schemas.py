from typing import Any

ALLOWED_TRANSACTION_TYPES = {"income", "expense"}
DEFAULT_CATEGORIES = [
    "Food", "Transport", "Education", "Shopping",
    "Bills", "Entertainment", "Health", "Other"
]

def validate_transaction_payload(payload: Any) -> tuple[bool, str]:
    if not isinstance(payload, dict):
        return False, "Request body must be a JSON object."
    title = str(payload.get("title", "")).strip()
    amount = payload.get("amount")
    tx_type = str(payload.get("type", "")).strip().lower()
    category = str(payload.get("category", "Other")).strip() or "Other"

    if not title:
        return False, "Title is required."
    try:
        amount_value = float(amount)
    except (TypeError, ValueError):
        return False, "Amount must be a number."
    if amount_value <= 0:
        return False, "Amount must be greater than zero."
    if tx_type not in ALLOWED_TRANSACTION_TYPES:
        return False, "Type must be income or expense."
    if len(title) > 120:
        return False, "Title is too long."
    if len(category) > 60:
        return False, "Category is too long."
    return True, ""
