from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

from .config import FLASK_DEBUG, PORT, ROOT_DIR
from .database import (
    add_transaction, delete_transaction, get_budget, get_summary,
    init_db, list_transactions, set_budget
)
from .gemini_service import gemini_service
from .schemas import DEFAULT_CATEGORIES, validate_transaction_payload

FRONTEND_DIR = ROOT_DIR / "frontend"
app = Flask(__name__, static_folder=str(FRONTEND_DIR), static_url_path="")
CORS(app)

@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")

@app.get("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "app": "PocketSmart AI",
        "gemini_configured": gemini_service.enabled,
    })

@app.get("/api/categories")
def categories():
    return jsonify(DEFAULT_CATEGORIES)

@app.get("/api/transactions")
def transactions():
    return jsonify(list_transactions())

@app.post("/api/transactions")
def create_transaction():
    payload = request.get_json(silent=True)
    valid, message = validate_transaction_payload(payload)
    if not valid:
        return jsonify({"error": message}), 400
    transaction_id = add_transaction(
        str(payload["title"]).strip(),
        round(float(payload["amount"]), 2),
        str(payload["type"]).strip().lower(),
        str(payload.get("category", "Other")).strip() or "Other",
    )
    return jsonify({
        "id": transaction_id,
        "message": "Transaction added successfully."
    }), 201

@app.delete("/api/transactions/<int:transaction_id>")
def remove_transaction(transaction_id):
    if not delete_transaction(transaction_id):
        return jsonify({"error": "Transaction not found."}), 404
    return jsonify({"message": "Transaction deleted."})

@app.get("/api/summary")
def summary():
    return jsonify(get_summary())

@app.get("/api/budget")
def budget():
    return jsonify({"monthly_budget": get_budget()})

@app.put("/api/budget")
def update_budget():
    payload = request.get_json(silent=True) or {}
    try:
        amount = float(payload.get("monthly_budget"))
    except (TypeError, ValueError):
        return jsonify({"error": "monthly_budget must be a number."}), 400
    if amount < 0:
        return jsonify({"error": "Budget cannot be negative."}), 400
    amount = round(amount, 2)
    set_budget(amount)
    return jsonify({"monthly_budget": amount})

@app.post("/api/ai/insight")
def ai_insight():
    try:
        return jsonify(gemini_service.budget_insight(get_summary()))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 503

@app.post("/api/ai/recommend")
def ai_recommend():
    payload = request.get_json(silent=True) or {}
    category = str(payload.get("category", "")).strip()
    preference = str(payload.get("preference", "")).strip()
    try:
        budget_value = float(payload.get("budget"))
    except (TypeError, ValueError):
        return jsonify({"error": "budget must be a number."}), 400
    if not category:
        return jsonify({"error": "category is required."}), 400
    if budget_value <= 0:
        return jsonify({"error": "budget must be greater than zero."}), 400
    if len(preference) > 300:
        return jsonify({"error": "preference is too long."}), 400
    try:
        return jsonify(gemini_service.recommendation(
            category, round(budget_value, 2),
            preference or "No additional preference", get_summary()
        ))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 503

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=PORT, debug=FLASK_DEBUG)
else:
    init_db()
