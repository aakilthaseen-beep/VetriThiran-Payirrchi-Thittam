import sqlite3
from contextlib import contextmanager
from datetime import datetime
from .config import DATABASE_PATH

@contextmanager
def get_db():
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()

def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                type TEXT NOT NULL CHECK(type IN ('income', 'expense')),
                category TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        db.execute("""
            INSERT OR IGNORE INTO settings(key, value)
            VALUES ('monthly_budget', '0')
        """)

def list_transactions():
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM transactions ORDER BY created_at DESC, id DESC"
        ).fetchall()
        return [dict(row) for row in rows]

def add_transaction(title, amount, tx_type, category):
    created_at = datetime.now().isoformat(timespec="seconds")
    with get_db() as db:
        cursor = db.execute(
            """INSERT INTO transactions(title, amount, type, category, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (title, amount, tx_type, category, created_at),
        )
        return cursor.lastrowid

def delete_transaction(transaction_id):
    with get_db() as db:
        cursor = db.execute(
            "DELETE FROM transactions WHERE id = ?", (transaction_id,)
        )
        return cursor.rowcount > 0

def get_budget():
    with get_db() as db:
        row = db.execute(
            "SELECT value FROM settings WHERE key = 'monthly_budget'"
        ).fetchone()
        return float(row["value"]) if row else 0.0

def set_budget(amount):
    with get_db() as db:
        db.execute(
            """INSERT INTO settings(key, value) VALUES ('monthly_budget', ?)
               ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
            (str(amount),),
        )

def get_summary():
    with get_db() as db:
        income = db.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE type='income'"
        ).fetchone()["total"]
        expenses = db.execute(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM transactions WHERE type='expense'"
        ).fetchone()["total"]
        categories = db.execute(
            """SELECT category, ROUND(SUM(amount), 2) AS total
               FROM transactions WHERE type='expense'
               GROUP BY category ORDER BY total DESC"""
        ).fetchall()

    budget = get_budget()
    balance = income - expenses
    usage_percent = (expenses / budget * 100) if budget > 0 else 0
    return {
        "income": round(income, 2),
        "expenses": round(expenses, 2),
        "balance": round(balance, 2),
        "budget": round(budget, 2),
        "budget_remaining": round(max(budget - expenses, 0), 2),
        "budget_usage_percent": round(usage_percent, 2),
        "categories": [
            {"category": row["category"], "total": row["total"]} for row in categories
        ],
    }
