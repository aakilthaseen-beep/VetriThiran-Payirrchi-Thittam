const money = (value) => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 2
}).format(Number(value || 0));

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: {"Content-Type": "application/json"}, ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed: ${response.status}`);
  return data;
}

function escapeHtml(value) {
  return String(value).replaceAll("&","&amp;").replaceAll("<","&lt;")
    .replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

async function loadDashboard() {
  const [summary, transactions, budget] = await Promise.all([
    api("/api/summary"), api("/api/transactions"), api("/api/budget")
  ]);
  document.querySelector("#income").textContent = money(summary.income);
  document.querySelector("#expenses").textContent = money(summary.expenses);
  document.querySelector("#balance").textContent = money(summary.balance);
  document.querySelector("#budgetUsage").textContent = `${summary.budget_usage_percent}%`;
  document.querySelector("#budgetInput").value = budget.monthly_budget || "";
  renderCategories(summary.categories);
  renderTransactions(transactions);
}

function renderCategories(categories) {
  const container = document.querySelector("#categories");
  if (!categories.length) { container.innerHTML = '<p class="muted">No expenses yet.</p>'; return; }
  const max = Math.max(...categories.map(x => Number(x.total)), 1);
  container.innerHTML = categories.map(item => `
    <div class="category-item">
      <span>${escapeHtml(item.category)}</span><strong>${money(item.total)}</strong>
      <div class="bar"><span style="width:${(item.total/max)*100}%"></span></div>
    </div>`).join("");
}

function renderTransactions(transactions) {
  const body = document.querySelector("#transactionTable");
  if (!transactions.length) {
    body.innerHTML = '<tr><td colspan="5" class="muted">No transactions yet.</td></tr>';
    return;
  }
  body.innerHTML = transactions.map(tx => `
    <tr><td>${escapeHtml(tx.title)}</td><td>${escapeHtml(tx.category)}</td>
    <td class="type-${tx.type}">${escapeHtml(tx.type)}</td><td>${money(tx.amount)}</td>
    <td><button class="delete-btn" onclick="removeTransaction(${tx.id})">Delete</button></td></tr>
  `).join("");
}

async function removeTransaction(id) {
  if (!confirm("Delete this transaction?")) return;
  try { await api(`/api/transactions/${id}`, {method:"DELETE"}); await loadDashboard(); }
  catch (error) { alert(error.message); }
}

document.querySelector("#transactionForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = document.querySelector("#formMessage");
  message.className = "message"; message.textContent = "";
  try {
    await api("/api/transactions", {method:"POST", body:JSON.stringify({
      title: document.querySelector("#title").value,
      amount: Number(document.querySelector("#amount").value),
      type: document.querySelector("#type").value,
      category: document.querySelector("#category").value
    })});
    event.target.reset(); document.querySelector("#type").value = "expense";
    message.textContent = "Transaction added."; await loadDashboard();
  } catch(error) { message.textContent = error.message; message.className = "message error"; }
});

document.querySelector("#saveBudgetBtn").addEventListener("click", async () => {
  try {
    await api("/api/budget", {method:"PUT", body:JSON.stringify({
      monthly_budget: Number(document.querySelector("#budgetInput").value)
    })});
    await loadDashboard();
  } catch(error) { alert(error.message); }
});

document.querySelector("#insightBtn").addEventListener("click", async () => {
  const result = document.querySelector("#insightResult");
  result.innerHTML = "<p>Gemini is analyzing your budget...</p>";
  try {
    const data = await api("/api/ai/insight", {method:"POST"});
    result.innerHTML = `<h3>${escapeHtml(data.headline)}</h3>
      <p>${escapeHtml(data.summary)}</p>
      <ul>${(data.actions||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul>
      ${data.warning ? `<p><strong>Note:</strong> ${escapeHtml(data.warning)}</p>` : ""}`;
  } catch(error) { result.innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`; }
});

document.querySelector("#recommendBtn").addEventListener("click", async () => {
  const result = document.querySelector("#recommendResult");
  result.innerHTML = "<p>Gemini is preparing a recommendation...</p>";
  try {
    const data = await api("/api/ai/recommend", {method:"POST", body:JSON.stringify({
      category: document.querySelector("#recommendCategory").value,
      budget: Number(document.querySelector("#recommendBudget").value),
      preference: document.querySelector("#recommendPreference").value
    })});
    result.innerHTML = `<h3>${escapeHtml(data.recommendation)}</h3>
      <ul>${(data.why||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul>
      <strong>Checklist</strong>
      <ul>${(data.shopping_checklist||[]).map(x=>`<li>${escapeHtml(x)}</li>`).join("")}</ul>
      ${data.note ? `<p><strong>Note:</strong> ${escapeHtml(data.note)}</p>` : ""}`;
  } catch(error) { result.innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`; }
});

async function checkHealth() {
  const badge = document.querySelector("#healthBadge");
  try {
    const data = await api("/api/health");
    badge.textContent = data.gemini_configured ? "API online • Gemini ready" : "API online • Add Gemini key";
  } catch { badge.textContent = "API unavailable"; }
}

(async function init() {
  await checkHealth();
  try { await loadDashboard(); } catch(error) { console.error(error); }
})();
